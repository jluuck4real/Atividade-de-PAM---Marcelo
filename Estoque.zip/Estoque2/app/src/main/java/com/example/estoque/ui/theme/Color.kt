package com.example.estoque.ui.theme

import androidx.compose.ui.graphics.Color

val AzulPrincipal = Color(0xFF1565C0)
val AzulEscuro = Color(0xFF003C8F)
val Branco = Color(0xFFFFFFFF)
val CinzaClaro = Color(0xFFF5F5F5)