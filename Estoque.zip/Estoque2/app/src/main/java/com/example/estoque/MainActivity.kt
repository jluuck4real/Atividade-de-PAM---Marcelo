package com.example.estoque

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.estoque.ui.theme.EstoqueTheme

data class Produto(
    val nome: String,
    val quantidade: Int
)

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            EstoqueTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    TelaEstoque()
                }
            }
        }
    }
}

@Composable
fun TelaEstoque() {

    val context = LocalContext.current

    val dbHelper = remember {
        DBHelper(context)
    }

    var nome by remember {
        mutableStateOf("")
    }

    var quantidade by remember {
        mutableStateOf("")
    }

    var produtos by remember {
        mutableStateOf(dbHelper.listarProdutos())
    }

    fun atualizarLista() {
        produtos = dbHelper.listarProdutos()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),

        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {

        Text(
            text = "Controle de Estoque",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = nome,

            onValueChange = {
                nome = it
            },

            label = {
                Text("Nome do Produto")
            },

            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = quantidade,

            onValueChange = {
                quantidade = it
            },

            label = {
                Text("Quantidade")
            },

            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {

                val qtd = quantidade.toIntOrNull()

                if (
                    nome.isNotEmpty() &&
                    qtd != null
                ) {

                    val sucesso =
                        dbHelper.cadastrarProduto(
                            nome,
                            qtd
                        )

                    if (sucesso) {

                        Toast.makeText(
                            context,
                            "Produto cadastrado",
                            Toast.LENGTH_SHORT
                        ).show()

                        atualizarLista()

                        nome = ""
                        quantidade = ""

                    } else {

                        Toast.makeText(
                            context,
                            "Produto já existe",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                } else {

                    Toast.makeText(
                        context,
                        "Preencha os campos",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            },

            modifier = Modifier.fillMaxWidth()
        ) {

            Text("Cadastrar Produto")
        }

        Button(
            onClick = {

                val qtd = quantidade.toIntOrNull()

                if (
                    nome.isNotEmpty() &&
                    qtd != null
                ) {

                    dbHelper.entradaEstoque(
                        nome,
                        qtd
                    )

                    atualizarLista()

                    quantidade = ""

                    Toast.makeText(
                        context,
                        "Entrada realizada",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            },

            modifier = Modifier.fillMaxWidth()
        ) {

            Text("Entrada de Estoque")
        }

        Button(
            onClick = {

                val qtd = quantidade.toIntOrNull()

                if (
                    nome.isNotEmpty() &&
                    qtd != null
                ) {

                    dbHelper.saidaEstoque(
                        nome,
                        qtd
                    )

                    atualizarLista()

                    quantidade = ""

                    Toast.makeText(
                        context,
                        "Saída realizada",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            },

            modifier = Modifier.fillMaxWidth()
        ) {

            Text("Saída de Estoque")
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Produtos Cadastrados",
            style = MaterialTheme.typography.titleLarge
        )

        LazyColumn {

            items(produtos) { produto ->

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp)
                ) {

                    Column(
                        modifier = Modifier.padding(15.dp)
                    ) {

                        Text(
                            text = "Produto: ${produto.nome}"
                        )

                        Text(
                            text = "Quantidade: ${produto.quantidade}"
                        )

                        Spacer(
                            modifier = Modifier.height(10.dp)
                        )

                        Button(
                            onClick = {

                                dbHelper.excluirProduto(
                                    produto.nome
                                )

                                atualizarLista()

                                Toast.makeText(
                                    context,
                                    "Produto excluído",
                                    Toast.LENGTH_SHORT
                                ).show()
                            },

                            colors =
                                ButtonDefaults.buttonColors(
                                    containerColor =
                                        MaterialTheme.colorScheme.error
                                ),

                            modifier = Modifier.fillMaxWidth()
                        ) {

                            Text("Excluir")
                        }
                    }
                }
            }
        }
    }
}