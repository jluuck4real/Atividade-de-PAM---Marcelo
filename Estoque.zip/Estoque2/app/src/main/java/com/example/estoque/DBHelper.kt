package com.example.estoque

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context) :
    SQLiteOpenHelper(
        context,
        "estoque.db",
        null,
        1
    ) {

    override fun onCreate(db: SQLiteDatabase) {

        db.execSQL(
            """
            CREATE TABLE produtos (
            
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT UNIQUE,
                quantidade INTEGER
            
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(
        db: SQLiteDatabase,
        oldVersion: Int,
        newVersion: Int
    ) {

        db.execSQL(
            "DROP TABLE IF EXISTS produtos"
        )

        onCreate(db)
    }

    fun cadastrarProduto(
        nome: String,
        quantidade: Int
    ): Boolean {

        val db = writableDatabase

        val values = ContentValues().apply {

            put("nome", nome)
            put("quantidade", quantidade)
        }

        val resultado = db.insert(
            "produtos",
            null,
            values
        )

        db.close()

        return resultado != -1L
    }

    fun listarProdutos(): MutableList<Produto> {

        val lista = mutableListOf<Produto>()

        val db = readableDatabase

        val cursor = db.rawQuery(
            "SELECT * FROM produtos",
            null
        )

        if (cursor.moveToFirst()) {

            do {

                val nome = cursor.getString(
                    cursor.getColumnIndexOrThrow("nome")
                )

                val quantidade = cursor.getInt(
                    cursor.getColumnIndexOrThrow("quantidade")
                )

                lista.add(
                    Produto(
                        nome,
                        quantidade
                    )
                )

            } while (cursor.moveToNext())
        }

        cursor.close()
        db.close()

        return lista
    }

    fun entradaEstoque(
        nome: String,
        quantidade: Int
    ) {

        val db = writableDatabase

        db.execSQL(
            """
            UPDATE produtos
            SET quantidade = quantidade + ?
            WHERE nome = ?
            """.trimIndent(),

            arrayOf(
                quantidade,
                nome
            )
        )

        db.close()
    }

    fun saidaEstoque(
        nome: String,
        quantidade: Int
    ) {

        val db = writableDatabase

        db.execSQL(
            """
            UPDATE produtos
            
            SET quantidade = quantidade - ?
            
            WHERE nome = ?
            AND quantidade >= ?
            """.trimIndent(),

            arrayOf(
                quantidade,
                nome,
                quantidade
            )
        )

        db.close()
    }

    fun excluirProduto(nome: String) {

        val db = writableDatabase

        db.delete(
            "produtos",
            "nome = ?",
            arrayOf(nome)
        )

        db.close()
    }
}